package LocadoraVeiculos;

public class CategoriaVeiculo {
    private String nome;
    private double taxaDiaria;
    private double taxaPorKm;

    public CategoriaVeiculo(String nome, double taxaDiaria, double taxaPorKm) {
        this.nome = nome;
        this.taxaDiaria = taxaDiaria;
        this.taxaPorKm = taxaPorKm;
    }

    public String getNome() {
        return nome;
    }

    public double getTaxaDiaria() {
        return taxaDiaria;
    }

    public double getTaxaPorKm() {
        return taxaPorKm;
    }


}
