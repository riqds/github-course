package LocadoraVeiculos;

public interface LocacaoVeiculo {
    double calcularValor();

}
