package LocadoraVeiculos;

public class Principal {
    public static void main(String[] args) {
        Locadora locadora = new Locadora();

        CategoriaVeiculo hatch = new CategoriaVeiculo("Hatch", 100.0, 0.2);
        CategoriaVeiculo sedan = new CategoriaVeiculo("Sedan", 120.0, 0.25);
        CategoriaVeiculo suv = new CategoriaVeiculo("SUV", 150.0, 0.50);
        locadora.cadastrarCategoria(hatch);
        locadora.cadastrarCategoria(sedan);
        locadora.cadastrarCategoria(suv);

        Menu menu = new Menu(locadora);
        menu.exibirMenu();
    }
}

