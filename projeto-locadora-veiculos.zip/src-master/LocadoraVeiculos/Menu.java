package LocadoraVeiculos;

import java.util.Scanner;

public class Menu {
    private Locadora locadora;

    public Menu(Locadora locadora) {
        this.locadora = locadora;
    }

    public void exibirMenu() {
        Scanner scanner = new Scanner(System.in);
        int opcao;

        do {
            System.out.println("===== Menu da Locadora =====");
            System.out.println("1. Cadastrar Cliente");
            System.out.println("2. Atualizar Cliente");
            System.out.println("3. Listar Clientes");
            System.out.println("4. Remover Cliente");
            System.out.println("5. Cadastrar Veículo");
            System.out.println("6. Listar Veículos");
            System.out.println("7. Remover Veículo");
            System.out.println("8. Alugar Veículo");
            System.out.println("9. Devolver Veículo");
            System.out.println("10. Listar Veículos Alugados por Cliente");
            System.out.println("11. Buscar Cliente por CPF");
            System.out.println("12. Calcular Aluguel do Veículo");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    cadastrarCliente();
                    break;
                case 2:
                    atualizarCliente();
                    break;
                case 3:
                    listarClientes();
                    break;
                case 4:
                    removerCliente();
                    break;
                case 5:
                    cadastrarVeiculo();
                    break;
                case 6:
                    listarVeiculos();
                    break;
                case 7:
                    removerVeiculo();
                    break;
                case 8:
                    alugarVeiculo();
                    break;
                case 9:
                    devolverVeiculo();
                    break;
                case 10:
                    listarVeiculosAlugadosPorCliente();
                    break;
                case 11:
                    buscarClientePorCpf();
                    break;
                case 12:
                    calcularAluguelVeiculo();
                    break;
                case 0:
                    System.out.println("Saindo do programa.");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
                    break;
            }
        } while (opcao != 0);
    }

    private void cadastrarCliente() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Nome do Cliente: ");
        String nome = scanner.nextLine();
        System.out.print("Endereço: ");
        String endereco = scanner.nextLine();
        System.out.print("Telefone: ");
        String telefone = scanner.nextLine();
        System.out.print("CPF: ");
        String cpf = scanner.nextLine();
        System.out.print("RG: ");
        String rg = scanner.nextLine();

        Cliente cliente = new Cliente(nome, endereco, telefone, cpf, rg);
        locadora.cadastrarCliente(cliente);
    }

    private void atualizarCliente() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o CPF do cliente que deseja atualizar: ");
        String cpf = scanner.nextLine();

        Cliente clienteExistente = locadora.buscarClientePorCpf(cpf);

        if (clienteExistente != null) {
            System.out.println("Cliente encontrado:");
            System.out.println("Nome: " + clienteExistente.getNome());
            System.out.println("Endereço: " + clienteExistente.getEndereco());
            System.out.println("Telefone: " + clienteExistente.getTelefone());

            System.out.print("Novo Nome: ");
            String novoNome = scanner.nextLine();
            System.out.print("Novo Endereço: ");
            String novoEndereco = scanner.nextLine();
            System.out.print("Novo Telefone: ");
            String novoTelefone = scanner.nextLine();

            Cliente novoCliente = new Cliente(novoNome, novoEndereco, novoTelefone, clienteExistente.getCpf(), clienteExistente.getRg());


            locadora.atualizarCliente(cpf, novoCliente);

            System.out.println("Cliente atualizado com sucesso!");
        } else {
            System.out.println("Cliente com CPF " + cpf + " não encontrado.");
        }
    }

    private void listarClientes() {
        locadora.listarClientes();
    }


    private void removerCliente() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o CPF do cliente que deseja remover: ");
        String cpf = scanner.nextLine();
        locadora.removerCliente(cpf);
    }


    private void buscarClientePorCpf() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o CPF do cliente a ser buscado: ");
        String cpf = scanner.nextLine();

        Cliente clienteEncontrado = locadora.buscarClientePorCpf(cpf);

        if (clienteEncontrado != null) {
            System.out.println("Cliente encontrado:");
            System.out.println("Nome: " + clienteEncontrado.getNome());
            System.out.println("CPF: " + clienteEncontrado.getCpf());

        } else {
            System.out.println("Cliente não encontrado.");
        }
    }


    private void cadastrarVeiculo() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o nome da categoria do veículo: ");
        String nomeCategoria = scanner.nextLine();

        CategoriaVeiculo categoria = locadora.getCategoriaPorNome(nomeCategoria);

        if (categoria != null) {
            System.out.print("Digite o nome do veículo: ");
            String nomeVeiculo = scanner.nextLine();

            System.out.print("Digite a placa do veículo: ");
            String placa = scanner.nextLine();

            System.out.print("Digite os quilômetros rodados do veículo: ");
            int quilometrosRodados = scanner.nextInt();
            scanner.nextLine();

            Veiculo veiculo = new Carro(nomeVeiculo, placa, quilometrosRodados, categoria, locadora);
            locadora.cadastrarVeiculo(veiculo);
        } else {
            System.out.println("Categoria não encontrada.");
        }
    }



    private void listarVeiculos() {
        System.out.println("===== Lista de Veículos =====");
        Veiculo[] veiculos = locadora.getVeiculos();

        if (veiculos.length > 0) {
            for (Veiculo veiculo : veiculos) {
                System.out.println("Nome do Veículo: " + veiculo.getNomeVeiculo());
                System.out.println("Placa: " + veiculo.getPlaca());
                System.out.println("Quilômetros Rodados: " + veiculo.getQuilometrosRodados());
                System.out.println("Categoria: " + veiculo.getCategoria().getNome());
                System.out.println("=============================");
            }
        } else {
            System.out.println("Nenhum veículo cadastrado.");
        }
    }





    private void removerVeiculo() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o nome do veículo que deseja remover: ");
        String nomeVeiculo = scanner.nextLine();
        locadora.removerVeiculo(nomeVeiculo);
    }


    private void alugarVeiculo() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o CPF do cliente que deseja alugar um veículo: ");
        String cpfCliente = scanner.nextLine();

        System.out.print("Digite o nome do veículo que deseja alugar: ");
        String nomeVeiculo = scanner.nextLine();


        Cliente cliente = locadora.buscarClientePorCpf(cpfCliente);
        Veiculo veiculo = locadora.buscarVeiculoPorNome(nomeVeiculo);

        if (cliente != null && veiculo != null) {
            locadora.alugarVeiculo(cliente, veiculo);

        } else {
            System.out.println("Cliente ou veículo não encontrado.");
        }
    }


    private void devolverVeiculo() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o CPF do cliente que está devolvendo o veículo: ");
        String cpfCliente = scanner.nextLine();

        System.out.print("Digite o nome do veículo que está sendo devolvido: ");
        String nomeVeiculo = scanner.nextLine();

        Cliente cliente = locadora.buscarClientePorCpf(cpfCliente);
        Veiculo veiculo = locadora.buscarVeiculoPorNome(nomeVeiculo);

        if (cliente != null && veiculo != null) {

        } else {
            System.out.println("Cliente ou veículo não encontrado.");
        }
    }


    private void listarVeiculosAlugadosPorCliente() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o CPF do cliente: ");
        String cpfCliente = scanner.nextLine();

        Cliente cliente = locadora.buscarClientePorCpf(cpfCliente);

        if (cliente != null && cliente.temVeiculoAlugado()) {
            Veiculo veiculoAlugado = cliente.getVeiculoAlugado();

            System.out.println("Cliente: " + cliente.getNome());
            System.out.println("Veículo Alugado: " + veiculoAlugado.getNomeVeiculo());
            System.out.println("Placa: " + veiculoAlugado.getPlaca());
            System.out.println("Categoria: " + veiculoAlugado.getCategoria().getNome());
            System.out.println("=============================");
        } else {
            System.out.println("Cliente não encontrado ou o cliente não possui veículo alugado.");
        }
    }






    private void calcularAluguelVeiculo() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o CPF do cliente: ");
        String cpfCliente = scanner.nextLine();
        Cliente cliente = locadora.buscarClientePorCpf(cpfCliente);

        if (cliente != null) {
            System.out.print("Digite o nome do veículo: ");
            String nomeVeiculo = scanner.nextLine();
            Veiculo veiculo = locadora.buscarVeiculoPorNome(nomeVeiculo);

            if (veiculo != null) {
                System.out.print("Digite a quantidade de dias de aluguel: ");
                int diasAluguel = scanner.nextInt();

                veiculo.setDiasAluguel(diasAluguel);
                double valorAluguel = veiculo.calcularValor();

                System.out.println("Valor do aluguel: R$" + valorAluguel);
            } else {
                System.out.println("Veículo não encontrado.");
            }
        } else {
            System.out.println("Cliente não encontrado.");
        }
    }
}

