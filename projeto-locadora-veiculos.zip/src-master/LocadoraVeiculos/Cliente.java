package LocadoraVeiculos;

public class Cliente extends Pessoa {

    private Veiculo veiculoAlugado;
    private int diasAluguel;

        public Cliente(String nome, String endereco, String telefone, String cpf, String rg) {
            super(nome, endereco, telefone, cpf, rg);
        }

        public void alugarVeiculo(Veiculo veiculo, int diasAluguel) {
            this.veiculoAlugado = veiculo;
            this.diasAluguel = diasAluguel;
        }

        public Veiculo getVeiculoAlugado() {
            return veiculoAlugado;
        }

        public void setVeiculoAlugado(Veiculo veiculoAlugado) {
            this.veiculoAlugado = veiculoAlugado;
        }

        public int getDiasAluguel() {
            return diasAluguel;
        }

        public void setDiasAluguel(int diasAluguel) {
            this.diasAluguel = diasAluguel;
        }

        public boolean temVeiculoAlugado() {
            return veiculoAlugado != null;
        }

}
