package LocadoraVeiculos;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

public class Locadora {
    private List<Cliente> clientes = new ArrayList<>();
    private List<Veiculo> veiculos = new ArrayList<>();
    private Map<Cliente, Veiculo> veiculosAlugados = new HashMap<>();

    private Map<String, CategoriaVeiculo> categorias = new HashMap<>();

    private Locadora locadora;


    public void cadastrarCliente(Cliente cliente) {
        clientes.add(cliente);
    }



    public void atualizarCliente(String cpf, Cliente novoCliente) {
        for (int i = 0; i < clientes.size(); i++) {
            Cliente cliente = clientes.get(i);
            if (cliente.getCpf().equals(cpf)) {
                clientes.set(i, novoCliente);
                break;
            }
        }
    }

    public void listarClientes() {
        for (Cliente cliente : clientes) {
            System.out.println("Nome: " + cliente.getNome());
            System.out.println("CPF: " + cliente.getCpf());
            System.out.println("RG: " + cliente.getRg());
            System.out.println("Endereço: " + cliente.getEndereco());
            System.out.println("Telefone: " + cliente.getTelefone());
            System.out.println("=============================");
        }
    }

    public void removerCliente(String cpf) {
        Iterator<Cliente> iterator = clientes.iterator();
        while (iterator.hasNext()) {
            Cliente cliente = iterator.next();
            if (cliente.getCpf().equals(cpf)) {
                iterator.remove();
                Veiculo veiculo = veiculosAlugados.get(cliente);
                if (veiculo != null) {
                    veiculosAlugados.remove(cliente);
                    veiculos.add(veiculo);
                }
            }
        }
    }

    public void cadastrarVeiculo(Veiculo veiculo) {
        veiculos.add(veiculo);
    }

    public void listarVeiculos() {
        for (Veiculo veiculo : veiculos) {
            System.out.println("Nome do Veículo: " + veiculo.getNomeVeiculo());
            System.out.println("Placa: " + veiculo.getPlaca());
            System.out.println("Quilômetros Rodados: " + veiculo.getQuilometrosRodados());
            System.out.println("Categoria: " + veiculo.getCategoria().getNome());
            System.out.println("=============================");
        }
    }

    public void removerVeiculo(String nomeVeiculo) {
        Iterator<Veiculo> iterator = veiculos.iterator();
        while (iterator.hasNext()) {
            Veiculo veiculo = iterator.next();
            if (veiculo.getNomeVeiculo().equals(nomeVeiculo)) {
                iterator.remove();
            }
        }
    }

    public void alugarVeiculo(Cliente cliente, Veiculo veiculo) {
        if (veiculosAlugados.containsKey(cliente)) {
            Veiculo veiculoAnterior = veiculosAlugados.get(cliente);
            veiculos.add(veiculoAnterior);
        }

        veiculosAlugados.put(cliente, veiculo);
        veiculos.remove(veiculo);
    }

    public void devolverVeiculo(Cliente cliente) {
        if (veiculosAlugados.containsKey(cliente)) {
            Veiculo veiculo = veiculosAlugados.remove(cliente);
            veiculos.add(veiculo);
        }
    }

    public Veiculo getVeiculoAlugadoPorCliente(Cliente cliente) {
        if (veiculosAlugados.containsKey(cliente)) {
            return veiculosAlugados.get(cliente);
        }
        return null;
    }


    private void listarVeiculosAlugadosPorCliente() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o CPF do cliente: ");
        String cpfCliente = scanner.nextLine();

        Cliente cliente = locadora.buscarClientePorCpf(cpfCliente);

        if (cliente != null) {
            Veiculo veiculoAlugado = locadora.getVeiculoAlugadoPorCliente(cliente);

            if (veiculoAlugado != null) {
                System.out.println("Cliente: " + cliente.getNome());
                System.out.println("Veículo Alugado: " + veiculoAlugado.getNomeVeiculo());
                System.out.println("Placa: " + veiculoAlugado.getPlaca());
                System.out.println("Categoria: " + veiculoAlugado.getCategoria().getNome());
                System.out.println("=============================");
            } else {
                System.out.println("O cliente não possui veículo alugado.");
            }
        } else {
            System.out.println("Cliente não encontrado.");
        }
    }


    public Cliente buscarClientePorCpf(String cpf) {
        for (Cliente cliente : clientes) {
            if (cliente.getCpf().equals(cpf)) {
                return cliente;
            }
        }
        return null;
    }

    public Veiculo[] getVeiculos() {
        Veiculo[] veiculosArray = new Veiculo[veiculos.size()];

        for (int i = 0; i < veiculos.size(); i++) {
            veiculosArray[i] = veiculos.get(i);
        }

        return veiculosArray;
    }

    public void cadastrarCategoria(CategoriaVeiculo categoria) {
        categorias.put(categoria.getNome(), categoria);
    }


    public CategoriaVeiculo getCategoriaPorNome(String nomeCategoria) {
        for (CategoriaVeiculo categoria : categorias.values()) {
            if (categoria.getNome().equalsIgnoreCase(nomeCategoria)) {
                return categoria;
            }
        }
        return null;
    }


    public Veiculo buscarVeiculoPorNome(String nomeVeiculo) {
        for (Veiculo veiculo : veiculos) {
            if (veiculo.getNomeVeiculo().equals(nomeVeiculo)) {
                return veiculo;
            }
        }
        return null;
    }




}
