package LocadoraVeiculos;

public class Carro extends Veiculo implements Categorizavel {
    private CategoriaVeiculo categoria;
    private Locadora locadora;

    public Carro(String nomeVeiculo, String placa, int quilometrosRodados, CategoriaVeiculo categoria, Locadora locadora) {
        super(nomeVeiculo, placa, quilometrosRodados);
        this.categoria = categoria;
        this.locadora = locadora;
    }

    @Override
    public double calcularValor() {
        int diasAluguel = getDiasAluguel();
        int quilometrosRodados = getQuilometrosRodados();

        double valorDiaria = categoria.getTaxaDiaria();
        double valorPorKm = categoria.getTaxaPorKm();

        double valorTotal = (double) ((valorDiaria * diasAluguel) + (valorPorKm * quilometrosRodados));
        return valorTotal;
    }

    @Override
    public CategoriaVeiculo getCategoria() {
        return categoria;
    }

    @Override
    public void setCategoria(String nomeCategoria) {
        CategoriaVeiculo novaCategoria = locadora.getCategoriaPorNome(nomeCategoria);
        if (novaCategoria != null) {
            this.categoria = novaCategoria;
        } else {
            System.out.println("Categoria não encontrada.");
        }
    }
}





