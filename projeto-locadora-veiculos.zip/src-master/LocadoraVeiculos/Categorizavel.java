package LocadoraVeiculos;

public interface Categorizavel {
    CategoriaVeiculo getCategoria();
    void setCategoria(String categoria);
}



