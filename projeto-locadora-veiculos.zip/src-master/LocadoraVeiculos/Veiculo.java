package LocadoraVeiculos;

public abstract class Veiculo implements LocacaoVeiculo, Categorizavel{
    private String nomeVeiculo;
    private String placa;
    private int quilometrosRodados;

    private int diasAluguel;

    public Veiculo(String nomeVeiculo, String placa, int quilometrosRodados) {
        this.nomeVeiculo = nomeVeiculo;
        this.placa = placa;
        this.quilometrosRodados = quilometrosRodados;
    }

    public String getNomeVeiculo() {
        return nomeVeiculo;
    }

    public void setNomeVeiculo(String nomeVeiculo) {
        this.nomeVeiculo = nomeVeiculo;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public int getQuilometrosRodados() {
        return quilometrosRodados;
    }

    public void setQuilometrosRodados(int quilometrosRodados) {
        this.quilometrosRodados = quilometrosRodados;
    }

    public int getDiasAluguel() {
        return diasAluguel;
    }

    public void setDiasAluguel(int diasAluguel) {
        this.diasAluguel = diasAluguel;
    }

}